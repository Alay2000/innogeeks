import './Todoform.css'
import {useState} from 'react'
const Todoform=(props)=>{
    const utc = new Date().toJSON().slice(0,10);
    //Title
    const [title,setTitle] = useState('')
    const [todoDate,setTodoDate] = useState('')
    const [priority,setPriority] = useState('')
    //there is another way to create states

    // const[userinput,setInput]=useState({
    //     title:'',
    //     todoDate:'',
    //     priority:'Low'
    // })

    const titleChangeHandler = (event) => {
        setTitle(event.target.value)
        // setInput((prevState) => {
        //     return {...prevState, title: event.title.value}
        // });
        //console.log(event.target.value);
    };
    const todoDateChangeHandler = (event) => {
        setTodoDate(event.target.value)
        // setInput({
        //     ...userinput,
        //     todoDate:event.target.value
        // }) //this may create problem in high speed tasks and we may lose new data so use the above one.
       // console.log(event.target.value);
    }
    const priorityChangeHandler = (event) => {
        //setInput({
            setPriority(event.target.value)
        //     ...userinput,
        //     priority:event.target.value
        // })
       // console.log(event.target.value);
    }
    const submitHandler = (event) => {
        event.preventDefault();
        const userData = {
            title:title,
            date:new Date(todoDate),
            priority:priority
        }
        console.log("Title",title,"Date:",todoDate,"Priority",priority);
        props.onSaveClick(userData);
        setTitle("");
        setTodoDate(utc);
        setPriority("Medium");
    }
    return(
        <form onSubmit={submitHandler} >
            <div>
                <div className="todo-control">
                    <label htmlFor="title">Title</label>
                    <input type="text" name="title" id="title" onChange={titleChangeHandler} value={title} />
                </div>
                <div className="todo-control">
                    <label htmlFor="date">Date</label>
                    <input type="date" name="date" id="date" onChange={todoDateChangeHandler} value={todoDate} />
                </div>
                <div className="todo-control">
                    <label htmlFor='priority'>Priority</label>
                    <select onChange={priorityChangeHandler} value={priority}>
                        <option value="High">High</option>
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                    </select>

                </div>
                <div className="todo-actions">
                    <button type="submit" className='btn'>Add todo</button>
                </div>
            </div>

        </form>
    )
}
export default Todoform;