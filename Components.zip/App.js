
import Todos from "./Components/Todos/Todos";
import Newtodo from './Components/Newtodo/Newtodo'
import {useState} from 'react'
function App() {
  const INITIAL_TODO = [
    {
      id: "1",
      title: "This is first title new",
      priority: "High",
      date: new Date(2022, 7, 15),
    },
    {
      id: "2",
      title: "This is second title",
      priority: "Low",
      date: new Date(2022, 8, 15),
    },
    {
      id: "3",
      title: "This is third title",
      priority: "Medium",
      date: new Date(2021, 8, 15),
    },
    {
      id: "4",
      title: "This is fourth title",
      priority: "Medium",
      date: new Date(2022, 4, 25),
    },
  ];
  const [allTodos,setAllTodos] = useState(INITIAL_TODO);
  const dataSaveHandler = (usertodo)=>{
    console.log(usertodo);
    setAllTodos((prevData) => {
      return [usertodo, ...prevData];
    })
  }
  return (
    <div className="App">
      <Newtodo onDataReceive={dataSaveHandler} />
      <Todos todo={allTodos} />
    </div>
  );
}

export default App;
