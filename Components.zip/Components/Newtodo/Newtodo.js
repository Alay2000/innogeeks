import TodoForm from "../Todoform/Todoform";
import "./Newtodo.css"

const Newtodo = (props)=>{

    const getFormData = (formData) => {
        console.log(formData);
        const localData = {
            ...formData,
            id: Math.random().toString(),
        };
        props.onDataReceive(localData);
    }


    return (
        <div className="new-todo">
            <TodoForm onSaveClick={getFormData}/>
            
        </div>
    );
}

export default Newtodo;