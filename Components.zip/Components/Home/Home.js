import Card from "../UI/Card/Card";
import Button from "../UI/Button/Buttons";
import "./Home.css";
const Home = ()=>{
    return (
        <Card classname="home">
            <h1>Welcome User</h1>
            <Button>Logout</Button>
        </Card>
    )
}
export default Home;