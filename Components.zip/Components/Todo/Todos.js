import TodoItem from "../Todoitems/TodoItem";
import "./Todos.css";
import Card from "../TodoUI/Card";
const Todos = (props) => {
  const ALL_TODO = props.todo;
  return (
    <Card className="todos">
      {ALL_TODO.map((todo)=>(
    
        <TodoItem 
          title={todo.title}
          priority={todo.priority}
          date={todo.date}
          key={todo.id}
        />
        

      ))}
      
    </Card>
  );
};

export default Todos;
