import Card from "../UI/Card/Card"
import Button from "../UI/Button/Buttons"
import "./Login.css"
import {useState} from "react";
const Login = () => {
    const [userEmail,setUserEmail]=useState("");
    const [userPassword,setUserPassword]=useState("");
    const emailChangeHandler = (event)=>{
        setUserEmail(event.target.value);
    }
    const passwordChangeHandler = (event)=>{
        setUserPassword(event.target.value)
    }
    const submitHandler=(event)=>{
        event.preventDefault();
        console.log("Useremail",userEmail,"Password",userPassword);
    }
    return(
    <Card className="login">
        <form onSubmit={submitHandler}>
            
            <div className="control">
                <label htmlFor="email">E-mail</label>
                <input type="email" name="email" id="email" onChange={emailChangeHandler}></input>
            </div>
            <div className="control">
                <label htmlFor="password">Password</label>
                <input type="password" name="password" id="password" onChange={passwordChangeHandler}></input>
            </div>
            <div className="actions">
                <Button type="submit">LogIn</Button>
            </div>
        </form>
    </Card>
    )}
export default Login;